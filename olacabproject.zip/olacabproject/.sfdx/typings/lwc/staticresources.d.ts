declare module "@salesforce/resourceUrl/countup7" {
    var countup7: string;
    export default countup7;
}
declare module "@salesforce/resourceUrl/heatmap" {
    var heatmap: string;
    export default heatmap;
}
declare module "@salesforce/resourceUrl/heatmapmock" {
    var heatmapmock: string;
    export default heatmapmock;
}
declare module "@salesforce/resourceUrl/jQuery" {
    var jQuery: string;
    export default jQuery;
}
declare module "@salesforce/resourceUrl/leaflet" {
    var leaflet: string;
    export default leaflet;
}
declare module "@salesforce/resourceUrl/leaflet1" {
    var leaflet1: string;
    export default leaflet1;
}
declare module "@salesforce/resourceUrl/nouislider" {
    var nouislider: string;
    export default nouislider;
}
declare module "@salesforce/resourceUrl/vfimagetest" {
    var vfimagetest: string;
    export default vfimagetest;
}
