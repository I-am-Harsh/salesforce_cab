import {
    LightningElement,
    api
} from 'lwc';
import {
    NavigationMixin
} from 'lightning/navigation';
import {
    ShowToastEvent
} from 'lightning/platformShowToastEvent';
 //import star from '@salesforce/resourceUrl/Star_Image';
import deleteDriverInfo from '@salesforce/apex/olaController.deleteDriverInfo';

export default class InfoDisplay extends NavigationMixin(LightningElement) {

    @api driver;
    @api error;
    //starLogo = star;
    editInfo(event) {
        console.log('sds' + this.driver.Name);
        //console.log(this.starLogo);
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: this.driver.Id,
                objectApiName: 'DriverInfo__c', // objectApiName is optional
                actionName: 'edit'
            }
        });
    }

    deleteRecordInfo(event) {
        
        console.log(this.driver.Id);
        deleteDriverInfo({
                driver: this.driver.Id
            })
            .then()
            .catch(error => {
                this.error = error;
            });

        const evt = new ShowToastEvent({
            title: "Driver deleted",
            message: "Record ID: " + this.driver.Id,
            variant: "success"
        });
        this.dispatchEvent(evt);
        console.log('Deleted');
        window.location.reload();

    }
}
