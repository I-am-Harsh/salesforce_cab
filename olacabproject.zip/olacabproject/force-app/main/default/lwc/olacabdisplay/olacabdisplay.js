import { LightningElement, wire, track } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { deleteRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import {refreshApex} from '@salesforce/apex';
import getrecords from '@salesforce/apex/olacabpracticecontroller.getrecords';
const col = [
    { label: 'Customername', fieldName:'CustomerName__c'},
    { label: 'Phone', fieldName: 'Phone__c' },
    { label: 'PickUp', fieldName: 'PickUpLocation__c' },
    { label: 'Drop', fieldName: 'DropLocation__c' }
];
export default class Olacabdisplay extends NavigationMixin(LightningElement) {
    @track details;
    @track error;
    @track columns=col;
    @track record='';
    @wire(getrecords)
        wireddetailsofcab({error,data})
        {
            console.log('groot');
            if(data){
                this.details=data;
                this.error=undefined;
            }
            if(error){
                this.details=undefined;
                this.error=error;
            } 
        }


        deleteRecord(){
            console.log('start deleting ');
            var recId=(this.template.querySelector('lightning-datatable').getSelectedRows()[0].Id);
            console.log('i am here in delete ' + recId);
            deleteRecord(recId)
                .then(() => {
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Success',
                            message: 'Record deleted',
                            variant: 'success'
                        })
                    );
                })
               
                .catch(error => {
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Error deleting record',
                            message: error.body.message,
                            variant: 'error'
                        })
                    );
                });
                location.reload();
            
        }
    
    
    editRecord(){
            this.record=this.template.querySelector('lightning-datatable').getSelectedRows()[0].Id;
            console.log(this.record);
            this[NavigationMixin.Navigate]({
                type: 'standard__recordPage',   
                attributes: {
                    recordId: this.record,
                    objectApiName: "olacabpractice__c",
                    actionName: "edit"  
                },
                
            });
            
        }
}