import { LightningElement, track, api} from 'lwc';
import getDriverInfo from '@salesforce/apex/olaController.getDriverInfo';
import { NavigationMixin } from 'lightning/navigation';
// import { encodeDefaultFieldValues } from 'lightning/pageReferenceUtils';
//import star from '@salesforce/resourceUrl/Star_Image';

import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import Name from '@salesforce/schema/DriverInfo__c.Name';
import Car_Type__c from '@salesforce/schema/DriverInfo__c.Car_Type__c';
import Car_Name__c from '@salesforce/schema/DriverInfo__c.Car_Name__c';
import Vehicle_Number__c from '@salesforce/schema/DriverInfo__c.Vehicle_Number__c';
import Rating__c from '@salesforce/schema/DriverInfo__c.Rating__c';

export default class OlaMain extends NavigationMixin(LightningElement) {


    fields = [Name, Car_Type__c, Car_Name__c, Vehicle_Number__c, Rating__c];
    @track info;
    @track errors;
    @api type = '';
    //starLogo = star;
    showInfo(event) {
        this.type = event.target.name;
        console.log(this.type);
        //
        getDriverInfo({
                type: this.type
            })
            .then(result => {
                this.info = result;
            })
            .catch(error => {
                this.errors = error;
            });
    }
    @track bShowModal = false;

    /* javaScipt functions start */
    openModal() {
        // to open modal window set 'bShowModal' tarck value as true
        this.bShowModal = true;
    }

    closeModal() {
        // to close modal window set 'bShowModal' tarck value as false
        this.bShowModal = false;
    }

    handleSuccess(event) {
        const evt = new ShowToastEvent({
            title: "Driver created",
            message: "Record ID: " + event.detail.id,
            variant: "success"
        });
        this.dispatchEvent(evt);
    }

}

