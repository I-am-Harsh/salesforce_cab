import { LightningElement, wire, track } from 'lwc';
import EMP from '@salesforce/schema/EmployeePractice__c';
import name from '@salesforce/schema/EmployeePractice__c.Employee_Name__c';
import phone from '@salesforce/schema/EmployeePractice__c.Phone__c';
import pos from '@salesforce/schema/EmployeePractice__c.Position__c';
import ID_FIELD from '@salesforce/schema/EmployeePractice__c.Id';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
//import addemployee from '@salesforce/apex/addemployee.addemployee';
import getrecord from '@salesforce/apex/addemployee.getrecord';
import { updateRecord } from 'lightning/uiRecordApi';
const col = [
    { label: 'Employeename', fieldName:'Employee_Name__c',editable:true},
    { label: 'Phone', fieldName: 'Phone__c' ,editable:true},
    { label: 'Position', fieldName: 'Position__c' ,editable:true},
];
export default class Employee extends LightningElement {

    employeeObject=EMP;
    employeeFields=[name,phone,pos];

    addemployee(){
        console.log(this.employeeFields);
    }
    @track details;
    @track error;
    @track columns=col;
    @track record='';
    @track draftValues = [];
    @wire(getrecord)
        wireddetailsofemp({error,data})
        {
            
            if(data){
                console.log(data);
                this.details=data;
                this.error=undefined;
            }
            if(error){
                this.details=undefined;
                this.error=error;
            } 
        }  
        handleSave(event) {

            const fields = {};
            fields[ID_FIELD.fieldApiName] = event.detail.draftValues[0].Id;
            fields[name.fieldApiName] = event.detail.draftValues[0].Employee_Name__c;
            fields[phone.fieldApiName] = event.detail.draftValues[0].Phone__c;
            fields[pos.fieldApiName] = event.detail.draftValues[0].Position__c;
            const recordInput = {fields};
            console.log(event.detail.draftValues[0].Name);
            updateRecord(recordInput)
            .then(() => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: 'Data updated',
                        variant: 'success'
                    })
                    
                );
                // Clear all draft values
                this.draftValues = [];
                
                // Display fresh data in the datatable
                return refreshApex(this.wireddetailsofemp);
            }).catch(error => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error creating record',
                        message: 'emp error',
                        variant: 'error'
                    })
                );
            });
        } 
}